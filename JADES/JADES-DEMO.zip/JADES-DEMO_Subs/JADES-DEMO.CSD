JADES-DEMO =
DG-SENS, All diesel start failures doubled
DG-UNAVAIL, Diesel generator A out of service
LOOP-FLAGS, After a loss of offsite power; AC to the feed pumps depends on the diesels
