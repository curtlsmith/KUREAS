JADES-DEMO, AFW =
AFW                      OR PUMPS CST-EMPTY
PUMPS                    AND TDP MDP
TDP                      OR TDP-FS TDP-FR
MDP                      OR MDP-FS MDP-FR MDP-POWER
MDP-POWER                AND /AC-AVAIL EPS
EPS                      TRAN
^EOS
JADES-DEMO, EPS =
EPS                      OR EPS-IND DG-CCF
EPS-IND                  AND TRAIN-A TRAIN-B
TRAIN-A                  OR DGA-FS DGA-FR DGA-TM BUS-A
TRAIN-B                  OR DGB-FS DGB-FR BUS-B
^EOS
JADES-DEMO, FB =
FB                       OR PORV-FO OP-FB
^EOS
JADES-DEMO, REC =
REC                      OR OP-REC
^EOS
